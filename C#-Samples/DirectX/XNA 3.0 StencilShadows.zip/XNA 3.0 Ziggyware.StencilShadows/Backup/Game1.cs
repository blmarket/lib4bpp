using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Net;
using Microsoft.Xna.Framework.Storage;

namespace Ziggyware.StencilShadows
{
    public class Game1 : Microsoft.Xna.Framework.Game
    {
        GraphicsDeviceManager graphics;

        float lightRotation = 0.0f;
        Vector3 lightPos;
        Model ground;
        Model scene;
        Plane lightPlane = new Plane(Vector3.Up, 0);
        QuadRendererComponent quadRenderer;
        Effect alphaEffect;
        Texture2D alphaTex;

        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            
            graphics.PreferredDepthStencilFormat = SelectStencilMode();

        }

        private DepthFormat SelectStencilMode()
        {
            // Check stencil formats
            GraphicsAdapter adapter = GraphicsAdapter.DefaultAdapter;
            SurfaceFormat format = adapter.CurrentDisplayMode.Format;
            if (adapter.CheckDepthStencilMatch(DeviceType.Hardware, 
                    format, format, DepthFormat.Depth24Stencil8))
                return DepthFormat.Depth24Stencil8;
            else if (adapter.CheckDepthStencilMatch(DeviceType.Hardware, 
                    format, format, DepthFormat.Depth24Stencil8Single))
                return DepthFormat.Depth24Stencil8Single;
            else if (adapter.CheckDepthStencilMatch(DeviceType.Hardware, 
                    format, format, DepthFormat.Depth24Stencil4))
                return DepthFormat.Depth24Stencil4;
            else if (adapter.CheckDepthStencilMatch(DeviceType.Hardware, 
                    format, format, DepthFormat.Depth15Stencil1))
                return DepthFormat.Depth15Stencil1;
            else
                throw new ApplicationException(
                    "Could Not Find Stencil Buffer for Default Adapter");
        }


        protected override void Initialize()
        {
            // TODO: Add your initialization logic here
            quadRenderer = new QuadRendererComponent(this);
            this.Components.Add(quadRenderer);

            base.Initialize();
        }

        protected override void LoadContent()
        {
            
            ground = Content.Load<Model>("content/ground");

            scene = Content.Load<Model>("content/scene");

            alphaEffect = Content.Load<Effect>("content/alphaQuad");

            alphaTex = Content.Load<Texture2D>("content/alphaTex");
        

            // TODO: Load any ResourceManagementMode.Manual content
        }


        

        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {
            // Allows the game to exit
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed)
                this.Exit();

            // TODO: Add your update logic here
            lightRotation += (float)gameTime.ElapsedGameTime.TotalSeconds;

            lightPos = Vector3.Right * 1000.0f * (float)Math.Cos(lightRotation) +
                            Vector3.Forward * 1000.0f * (float)Math.Sin(lightRotation)
                            + Vector3.Up*1500.0f;

            base.Update(gameTime);
        }


        private void DrawModel(Model model, Matrix world, Matrix view, Matrix projection,bool lit)
        {
            Matrix[] transforms = new Matrix[model.Bones.Count];
            model.CopyAbsoluteBoneTransformsTo(transforms);

            float depthBias = graphics.GraphicsDevice.RenderState.DepthBias;

            if (!lit)
            {
                graphics.GraphicsDevice.RenderState.DepthBias = -0.0001f;
            }

            foreach (ModelMesh mesh in model.Meshes)
            {
                foreach (BasicEffect effect in mesh.Effects)
                {
                    if(lit)
                    {
                        effect.LightingEnabled = true;
                        effect.EnableDefaultLighting();
                        effect.TextureEnabled = true;
                        effect.DiffuseColor = new Vector3(1, 1, 1);
                        effect.DirectionalLight0.Enabled = true;
                        effect.DirectionalLight1.Enabled = true;
                        effect.DirectionalLight2.Enabled = true;
                    }
                    else
                    {
                        effect.AmbientLightColor = Vector3.Zero;   
                        effect.LightingEnabled = false;
                        effect.DiffuseColor = Vector3.Zero;
                        effect.DirectionalLight0.Enabled = false;
                        effect.DirectionalLight1.Enabled = false;
                        effect.DirectionalLight2.Enabled = false;
                        effect.TextureEnabled = false;
                        effect.VertexColorEnabled = false;
                    }
                    effect.View = view;
                    effect.Projection = projection;
                    effect.World = transforms[mesh.ParentBone.Index] * world;

                    effect.CommitChanges();
                }
                mesh.Draw();
            }

            if (!lit)
            {
                graphics.GraphicsDevice.RenderState.DepthBias = depthBias;
            }
        }


        void RenderScene(GameTime gameTime)
        {

            Matrix view = Matrix.CreateLookAt(Vector3.Left * 100.0f +
                                                  Vector3.Up * 100.0f +
                                                  Vector3.Backward * 50.0f,
                                              Vector3.Zero,
                                              Vector3.Up);

            Matrix proj = Matrix.CreatePerspectiveFieldOfView(
                        MathHelper.PiOver2,
                        (float)graphics.GraphicsDevice.Viewport.AspectRatio,
                        5,
                        1500);

            Matrix world = Matrix.Identity;
            DrawModel(ground,
                    world,
                    view,
                    proj, true);

            DrawModel(scene,
                    world,
                    view,
                    proj, true);



            graphics.GraphicsDevice.Clear(ClearOptions.Stencil, Color.Black, 0, 0);

            
            graphics.GraphicsDevice.RenderState.StencilEnable = true;
            graphics.GraphicsDevice.RenderState.ColorWriteChannels = ColorWriteChannels.None;
            graphics.GraphicsDevice.RenderState.ReferenceStencil = 0;
            graphics.GraphicsDevice.RenderState.StencilFunction = CompareFunction.Equal;
            graphics.GraphicsDevice.RenderState.StencilPass = StencilOperation.Increment;


            world = Matrix.CreateShadow(
                        Vector3.Normalize(lightPos),
                        lightPlane);
            DrawModel(scene,
                    world,
                    view,
                    proj, false);

            
            graphics.GraphicsDevice.RenderState.ColorWriteChannels = ColorWriteChannels.All;
            graphics.GraphicsDevice.RenderState.ReferenceStencil = 1;
            graphics.GraphicsDevice.RenderState.StencilFunction = CompareFunction.Equal;
            graphics.GraphicsDevice.RenderState.AlphaBlendEnable = true;


            alphaEffect.Parameters["baseTexture"].SetValue(alphaTex);

            alphaEffect.Begin();
            alphaEffect.Techniques[0].Passes[0].Begin();

            quadRenderer.Render(-Vector2.One, Vector2.One );

            alphaEffect.Techniques[0].Passes[0].End();
            alphaEffect.End();

            graphics.GraphicsDevice.RenderState.AlphaBlendEnable = false;
            graphics.GraphicsDevice.RenderState.StencilEnable = false;
           
            
            base.Draw(gameTime);
        }

        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            graphics.GraphicsDevice.Clear(Color.CornflowerBlue);
            
            RenderScene(gameTime);
        }
    }
}
