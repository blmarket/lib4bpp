using System;
using System.Diagnostics;

namespace HexEngine
{
	/// <summary>
	/// Summary description for Hexagon.
	/// </summary>
	public class Hexagon
	{

		float side; 
		static int seed = 12; 
		static Random rand ; //new Random(11); // 
		int x; 
		int y; 

		int textNum; // = 

		public Hexagon(int X , int Y )
		{
			x = X; 
			y = Y; 

			seed = seed + 1; 
			seed = seed.GetHashCode(); 
			rand = new Random(seed); 
			int txt = rand.Next(HexGrid.NUMBER_OF_TEXTURES);
			textNum = txt; // hacked to 6 as we dont have

		}

/*		public float Radius { get { return this.Side * COS30;}}
		public float Width { get { return this.Radius * 2 ;}}
		public float Height { get { return 2*H + Side;}}
		public float Side { get { return this.Side;}}
		public float H  { get { return this.Side * SIN30; }}

		public float Gradient { get { return H/Radius;}}
*/ 
		
		public int TextureNumber { get { return textNum; }} //TODO


	}
}
