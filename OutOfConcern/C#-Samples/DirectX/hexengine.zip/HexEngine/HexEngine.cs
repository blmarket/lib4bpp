//-----------------------------------------------------------------------------
// Hex engine 
// 
// This code is freeware - it would be appreciated if you use it that you give me a mention
//   - If you make updates or fixes please send me a copy. 
//
//	Textures were borrowed 
//
// Ben Kloosterman ( bklooste@yahoo.com / ben.kloost@iotconsult.com.cn)
//-----------------------------------------------------------------------------
using System;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;
using Microsoft.DirectX;
using Microsoft.DirectX.Direct3D;




namespace HexEngine
{
	/// <summary>
	/// Application class. The base class (MyGraphicsSample) provides the generic 
	/// functionality needed in all Direct3D samples. MyGraphicsSample adds 
	/// functionality specific to this sample program.
	/// </summary>
	public class HexEngine: GraphicsSample
	{
		private GraphicsFont drawingFont = null;                 // Font for drawing text

		private HexGrid hexGrid; 


		private bool outLine = true; 

		//new
		Texture[] textures = null;
		Material mat; 
		//Vector3 eyepoint = new Vector3(0.1f, 25.0f,0.1f);
		Vector3 eyepoint = new Vector3(0.0f,-20f,0.0f);

		FillMode fillmode = FillMode.WireFrame;

		//indices buffer
		IndexBuffer[] indexBuffers = null;
		//IndexBuffer indexBuffer = null;
		//short[] indices;
		//Vertexbuffer
		VertexBuffer vertexBuffer = null;


        
        
        /// <summary>
		/// Application constructor. Sets attributes for the app.
		/// </summary>
		public HexEngine()
		{
			// Set the window text
			this.Text = "HexEngine";
            try
            {
                // Load the icon from our resources
                System.Resources.ResourceManager resources = new System.Resources.ResourceManager(this.GetType());
                this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            }
            catch
            {
                // It's no big deal if we can't load our icons, but try to load the embedded one
                try { this.Icon = new System.Drawing.Icon(this.GetType(), "directx.ico"); } 
                catch {}
            }

			this.hexGrid = HexGrid.Generate(50,50 ,5 );  // todo create hhexes

			drawingFont = new GraphicsFont("Arial", System.Drawing.FontStyle.Bold);
			enumerationSettings.AppUsesDepthBuffer= true;  // easy enough to do ourselves

			mat = new Material();
			mat.Specular = Color.Black;
			mat.Emissive = Color.Black;
			mat.Diffuse = Color.Black; 
			mat.SpecularSharpness = 0.1f; 

			this.KeyPress+= new System.Windows.Forms.KeyPressEventHandler(this.OnKeyPress);

			this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.OnPrivateKeyUp);

			this.Click += new EventHandler(this.OnMouseClick);
		}




		/// <summary>
		/// Called once per frame, the call is the entry point for animating the scene.
		/// </summary>
		protected override void FrameMove()
		{
			// Setup the lights and materials
			SetupLights();
			// Setup the world, view, and projection matrices
			//MoveEyePoint();
		}


		/// <summary>
		/// Called once per frame, the call is the entry point for 3d rendering. This 
		/// function sets up render states, clears the viewport, and renders the scene.
		/// </summary>
		protected override void Render()
		{
			//Clear the backbuffer to a black color 
			device.Clear(ClearFlags.Target | ClearFlags.ZBuffer, Color.Black, 1.0f, 0);
			//Begin the scene
			device.BeginScene();

			device.RenderState.FillMode = fillmode; 


			// set the vertexbuffer stream source
			//device.SetStreamSource(0, vertexBuffer, 0, VertexInformation.GetFormatSize(CustomVertex.PositionNormalTextured.Format));
			device.SetStreamSource(0, vertexBuffer, 0, VertexInformation.GetFormatSize(CustomVertex.PositionNormalTextured.Format));


			


	
			device.SetStreamSource(0, vertexBuffer, 0);
			device.VertexFormat = CustomVertex.PositionNormalTextured.Format;

			for (int texture_index = 0 ; texture_index <=  hexGrid.NumberOfTextures ; texture_index++ )
			{

				// Added
				device.SetTexture(0,textures[texture_index]);
				device.TextureState[texture_index].ColorOperation = TextureOperation.Modulate;
				device.TextureState[texture_index].ColorArgument1 = TextureArgument.TextureColor;
				device.TextureState[texture_index].ColorArgument2 = TextureArgument.Diffuse;
				device.TextureState[texture_index].AlphaOperation = TextureOperation.Add;

				// set the indices		
				if ( indexBuffers[texture_index] == null)  // set to null if nothing to do 
					continue; 
				device.Indices = indexBuffers[texture_index];
				// TODO we could use a mutlipass draw for 3 textures , this will eliminate a lot of vertex data as it can be shared 
				// but a lot of cards only support 2 textures. 

				//use the indices buffer
				// lets draw in lots of 6 				// eg draw 4 triangles ( 6 vetices) 
				//device.DrawIndexedPrimitives(PrimitiveType.TriangleList, 0, 0,hexGrid.X * hexGrid.Y * 6 ,0 , hexGrid.IndexBufferLength[texture_index]*4);
				device.DrawIndexedPrimitives(PrimitiveType.TriangleStrip, 0, 0,hexGrid.X * hexGrid.Y * 6 ,0 , hexGrid.IndexBufferLength[texture_index]*8 -2 );

			}

			if ( outLine == true)
			{
				device.TextureState[0].ColorOperation = TextureOperation.SelectArg2;
				//device.TextureState[0].AlphaOperation = TextureOperation.Add;
				device.Material = mat; 
				device.DrawPrimitives(PrimitiveType.LineList, 0, hexGrid.X * hexGrid.Y * 3);
			} 

			// Output statistics
			drawingFont.DrawText(2,  1, System.Drawing.Color.Yellow, frameStats);
			//drawingFont.DrawText(2, 20, System.Drawing.Color.Yellow, deviceStats);
			//drawingFont.DrawText(2, 40, System.Drawing.Color.White, "Hit 'F' to generate new fractal.");
			
			device.EndScene();
		}




		/// <summary>
        /// The device has been created.  Resources that are not lost on
        /// Reset() can be created here -- resources in Pool.Managed,
        /// Pool.Scratch, or Pool.SystemMemory.  Image surfaces created via
        /// CreateImageSurface are never lost and can be created here.  Vertex
        /// shaders and pixel shaders can also be created here as they are not
        /// lost on Reset().
		/// </summary>
		protected override void InitializeDeviceObjects()
		{
			drawingFont.InitializeDeviceObjects(device);
			
			//FractSetup();

			// Now Create the VB
			this.vertexBuffer = hexGrid.CreateVertexBuffer(device); 
			// hexGrid.GenerateVertexBufferData(vertexBuffer);

			vertexBuffer.Created += new System.EventHandler(this.OnCreateVertexBuffer);
			this.OnCreateVertexBuffer(vertexBuffer, null);

			//create the indices buffer

			//indexBuffer = new IndexBuffer(typeof(short), vert_size, device, Usage.WriteOnly, Pool.Default);
			//indices = new short[(bufferSize*6)*bufferSize];
			indexBuffers = hexGrid.CreateIndexBuffer(device); 
			// TODO foreach indexbuffer and send index 
			this.OnCreateIndex(indexBuffers, null);

			foreach(IndexBuffer indBuffer in indexBuffers )
			{
				if ( indBuffer != null) // can be null if no hexes of that type
					indBuffer.Created += new System.EventHandler(this.OnCreateIndex);
			}
			// note on a reset index buffers are recreated multiple times.... 

		}




		/// <summary>
        /// The device exists, but may have just been Reset().  Resources in
        /// Pool.Default and any other device state that persists during
        /// rendering should be set here.  Render states, matrices, textures,
        /// etc., that don't change during rendering can be set once here to
        /// avoid redundant state setting during Render() or FrameMove().
		/// </summary>
		protected override void RestoreDeviceObjects(System.Object sender, System.EventArgs e)
		{

			SetupMatrices();

			//device.VertexFormat = CustomVertex.PositionNormalTextured.Format;
			device.VertexFormat = CustomVertex.PositionNormalTextured.Format;

			// Turn off culling, so we see the front and back of the triangle
			// set fill mode
			//device.RenderState.CullMode = Cull.Clockwise;
			device.RenderState.CullMode = Cull.CounterClockwise;
			device.RenderState.AntiAliasedLineEnable = false;

			// Turn on the ZBuffer
			device.RenderState.ZBufferEnable = false;
			device.RenderState.Lighting = true;    //make sure lighting is turned on

			const string TEXT_DIR = "\\..\\..\\Textures"; 


			textures = new Texture[HexGrid.NUMBER_OF_TEXTURES]; 
			// new 
			try
			{
				// rock and rocks not great 
				textures[0] = TextureLoader.FromFile(device, Application.StartupPath + TEXT_DIR +  @"\\grass.dds");
				textures[1] = TextureLoader.FromFile(device, Application.StartupPath + TEXT_DIR +  @"\\mountains.dds");
				textures[2] = TextureLoader.FromFile(device, Application.StartupPath + TEXT_DIR +  @"\\ice.dds");
			}
			catch ( Exception ex)
			{
				Debug.WriteLine(ex);
			}
		}



        
        /// <summary>
        /// Setup the matrices
        /// </summary>
        private void SetupMatrices()
		{
			const float NEAR_Z = 1f; 
	
			// Set up our view matrix. A view matrix can be defined given an eye point,
			// a point to lookat, and a direction for which way is up. 
            device.Transform.View = Matrix.LookAtLH(this.eyepoint,
				new Vector3(0.001f, 0.0f, 0.001f), 
				new Vector3(0.0f, 1.0f, 0.0f));

			// translate to position in the middle 
			Matrix temp = Matrix.Translation((hexGrid.Width*-0.5f), 0, ( hexGrid.Height*-0.5f));
			// For our world matrix, we will just rotate 45 about the .Y-axis.
			device.Transform.World = Matrix.Multiply(temp , Matrix.RotationAxis(new Vector3(0,1f,0) ,(float) (Math.PI / 4.0f))); 

			// translate to position in the middle 
			//Matrix temp = Matrix.R.Translation((hexGrid.Width*-0.5f), 0, ( hexGrid.Height*-0.5f));
			// For our world matrix, we will just rotate 45 about the .Y-axis.
			//device.Transform.World = Matrix.Multiply(device.Transform.World , Matrix.RotationAxis(new Vector3(0,0, 1f) ,(float) ( Math.PI / 2.0f))); 


			// For the projection matrix, we set up a perspective transform (which
			// transforms geometry from 3D view space to 2D viewport space, with
			// a perspective divide making objects smaller in the distance). To build
			// a perpsective transform, we need the field of view (1/4 pi is common),
			// the aspect ratio, and the near and far clipping planes (which define at
			// what distances geometry should be no longer be rendered).

			device.Transform.Projection = Matrix.PerspectiveFovLH((float)Math.PI / 4.0f, 1.0f,NEAR_Z, 1000.0f) ; 


			//device.Transform.Projection = Matrix.P
		}

	/*	private void MoveEyePoint()
		{
			device.Transform.View = Matrix.LookAtLH(this.eyepoint,
				new Vector3(0.0f, 0.0f, 0.0f), 
				new Vector3(0.0f, 1.0f, 0.0f));
		}*/ 

        
        
        
        /// <summary>
        /// Setup the lights
        /// </summary>
        private void SetupLights()
		{
			Color col = Color.White;
			//Set up a material. The material here just has the diffuse and ambient
			//colors set to yellow. Note that only one material can be used at a time.
			Material mtrl = new Material();
			mtrl.Diffuse = 	mtrl.Ambient = col;
			device.Material = mtrl;
			
			//Set up a white, directional light, with an oscillating direction.
			//Note that many lights may be active at a time (but each one slows down
			//the rendering of our scene). However, here we are just using one. Also,
			//we need to set the D3DRS_LIGHTING renderstate to enable lighting
    
			//device.Lights[0].Specular = col;
			device.Lights[0].Type = LightType.Directional;
			device.Lights[0].Diffuse = Color.White;
			device.Lights[0].Direction = new Vector3(0, 1.0f,	0.0f);
			device.Lights[0].Commit();
			device.Lights[0].Enabled = true;
			//device.Lights[0].I


			// do textures use lights or only ambient ? 
			//Finally, turn on some ambient light.
			//Ambient light is light that scatters and lights all objects evenly
			device.RenderState.Ambient = Color.LightGray;
		}  
     
             
        /// <summary>
        /// Handle the vertex creation event
        /// </summary>
        public void OnCreateVertexBuffer(object sender, EventArgs e)
		{
			hexGrid.GenerateVertexBufferData((VertexBuffer) sender);
	
		}

		/// <summary>
		/// Handle the vertex creation event
		/// </summary>
		public void OnCreateIndex(object sender, EventArgs e)
		{
			// prob is all indexes are redone for each Index buffere reset... 
			// TODO fix 

			hexGrid.GenerateIndexBuffer( this.indexBuffers); 
		}

        
     
		const char myLeft = (char)252;
		const char myRight = (char)253;
		const char myUp = (char)254;
		const char myDown = (char)255;
		const char myPageUp = (char) 251;
		const char myPageDown = (char) 250;

		// not the best way at all ..looking for ideas. 
		protected override bool IsInputKey(Keys key) 
		{
			switch (key) 
			{
				case Keys.Left:
					OnKeyPress(new KeyPressEventArgs(myLeft));
					return true;
				case Keys.Right:
					OnKeyPress(new KeyPressEventArgs(myRight));
					return true;
				case Keys.Up:
					OnKeyPress(new KeyPressEventArgs(myUp));
					return true;
				case Keys.Down:
					OnKeyPress(new KeyPressEventArgs(myDown));
					return true;
				case Keys.PageDown:
					OnKeyPress(new KeyPressEventArgs(myPageDown));
					return true;
				case Keys.PageUp:
					OnKeyPress(new KeyPressEventArgs(myPageUp));
					return true;
				default:
					return base.IsInputKey(key);
			}
		}


		int repeatCount = 0; // used to see how many times a key is pressed
		/// <summary>
		/// Event Handler for windows messages
		/// </summary>
		private void OnPrivateKeyUp(object sender, System.Windows.Forms.KeyEventArgs e)
		{
			repeatCount = 0; 
			if (e.KeyCode == System.Windows.Forms.Keys.G)
			{
				this.outLine = !this.outLine; 
			}

			if (e.KeyCode == System.Windows.Forms.Keys.L)
			{
				this.device.RenderState.Lighting = !this.device.RenderState.Lighting; 
			}

			if (e.KeyCode == System.Windows.Forms.Keys.W)
			{
				if ( fillmode ==  FillMode.Solid )
					fillmode =  FillMode.WireFrame;
				else
					fillmode =  FillMode.Solid; 
			}
			if (e.KeyCode == System.Windows.Forms.Keys.C)
			{
				Centre(hexGrid.X/2 , hexGrid.Y/2 );  
			}
			if (e.KeyCode == System.Windows.Forms.Keys.O)
			{
				Centre(0 , 0);  
			}
		}

		/// <summary>
		/// Event Handler for windows messages
		/// </summary>
		private void OnKeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
		{
			//const int MAX_REPEAT = 10; 

			this.repeatCount++; 
			if ((repeatCount & 1 ) == 0)  //HACK to halve rate which repeat keys present
			{
				e.Handled = true; 
				return;
			} 
			//if ( this.repeatCount > MAX_REPEAT)
			// 	this.repeatCount = MAX_REPEAT;

			if (e.KeyChar == HexEngine.myPageDown)
			{
				Scroll(repeatCount , ScrollDirection.ZOOM_IN);  
				e.Handled = true; 
			}
			if (e.KeyChar == HexEngine.myPageUp)
			{
				Scroll(repeatCount , ScrollDirection.ZOOM_OUT);  
				e.Handled = true; 
			}
			if (e.KeyChar == HexEngine.myUp)
			{
				Scroll(repeatCount , ScrollDirection.UP ); 
				e.Handled = true; 
			}
			if (e.KeyChar == HexEngine.myDown)
			{
				Scroll(repeatCount , ScrollDirection.DOWN);  
				e.Handled = true; 
			}
			if (e.KeyChar == HexEngine.myLeft)
			{
				Scroll(repeatCount , ScrollDirection.LEFT);  
				e.Handled = true; 
			}
			if (e.KeyChar == HexEngine.myRight)
			{
				Scroll(repeatCount , ScrollDirection.RIGHT);  
				e.Handled = true; 
			}

		}

		/// <summary>
		/// Event Handler for windows messages
		/// </summary>
		private void OnMouseClick (object sender, EventArgs e)
		{
			Point mouse = this.PointToClient(Control.MousePosition);

			// adjust mouse for menu bar
			PointF loc = Pick(mouse.X , mouse.Y); 
			Point pnt = hexGrid.GetPointByPixel(loc.X , loc.Y);
			// Output location !!!
			Debug.WriteLine(pnt); 

		}

		/// <summary>
		///  Performas scrolls of the map 
		///  The methd checks to see if the sroll still remains on the screen 
		///  and adjusts the distance to scroll if it is too great
		/// </summary>
		/// <param name="amount"></param>
		/// <param name="direction"></param>
		public void Scroll(int amount , ScrollDirection direction )
		{

			const float MAX_HEIGHT =  500f;  
			const float MIN_HEIGHT = -10f ; // camera is at -20 
			const int EDGE = 0; 

			Point centre; //  = Point.Round(Pick( ClientRectangle.Width/2 , ClientRectangle.Height/2)); 
			Matrix temp = Matrix.Identity;
			float distance = amount * this.hexGrid.Radius;  // adjust to scale 

			// TODO check limits
			// TODO repeat rate to fast...

			switch (direction)
			{
				case ScrollDirection.DOWN:
					centre = Point.Round(Pick(  EDGE  , ClientRectangle.Height - EDGE)); 
					if (centre.Y > hexGrid.Height)
						return;

					if ( centre.Y + distance  + hexGrid.Radius /2>  hexGrid.Height )
						distance= Convert.ToInt32( Math.Max( 0f, (hexGrid.Height -  centre.Y + hexGrid.Radius + 1 ))); 

					temp = Matrix.Translation(0, 0, -distance);
					break;
				case ScrollDirection.UP:
					centre = Point.Round(Pick( EDGE  , EDGE)); // slight edge .. out by h. 
					if (centre.Y < 0)  
						return;
					if ( centre.Y < distance )
						distance  = centre.Y + 1 ; 
					temp = Matrix.Translation(0, 0, distance);
					break;
				case ScrollDirection.LEFT:
					centre = Point.Round(Pick( EDGE  , EDGE)); 
					if (centre.X < 0)
						return;
					if ( centre.X < distance)
						distance  = centre.X + 1 ; 
					temp = Matrix.Translation(distance,0 , 0);
					break;
				case ScrollDirection.RIGHT:
					centre = Point.Round(Pick( ClientRectangle.Width -  EDGE  , EDGE)); 
					if (centre.X > hexGrid.Width + hexGrid.Radius /2) // real width 
						return;

					if ( centre.X + distance  + hexGrid.Radius /2>  hexGrid.Width)
						distance= Convert.ToInt32( Math.Max( 0f, (hexGrid.Width -  centre.X + hexGrid.Radius + 1 ))); 

					temp = Matrix.Translation( -distance,0 , 0);
					break;
				case ScrollDirection.ZOOM_IN:
					if (device.Transform.World.M42 <= MIN_HEIGHT)
						return;
					if ( device.Transform.World.M42 - distance  <= MIN_HEIGHT)
						distance  = device.Transform.World.M42 - MIN_HEIGHT    ; 
					temp = Matrix.Translation(0,-distance, 0);
					break;
				case ScrollDirection.ZOOM_OUT:
					if (device.Transform.World.M42 >=  MAX_HEIGHT)
						return; 

					temp = Matrix.Translation(0, distance, 0 );
					break;
				default:
					throw new ArgumentException("Unknown direction");
			}	
			//Debug.WriteLine(temp);
			//Debug.WriteLine(device.Transform.World);
			
			device.Transform.World = Matrix.Multiply(temp , device.Transform.World); 
			//Debug.WriteLine(device.Transform.World);

		}



		// broken 0,0 goes to end 
		public void Centre( int X , int Y ) 
		{
			// save y 
			float saveY = device.Transform.World.M42;  
			// set world 
			
			// translate to position in the middle 
			// Debug.WriteLine(hexGrid.X); 
						//Matrix temp = Matrix.Translation((hexGrid.Width*-0.5f), 0, ( hexGrid.Height*-0.5f));
			float XRatio  = (hexGrid.Width * -X  / (float) hexGrid.X) ;
			float yRatio = (hexGrid.Height *  -Y  / (float) hexGrid.Y);
			Matrix temp = Matrix.Translation(XRatio, 0, yRatio );
			// For our world matrix, we will just rotate 45 about the .Y-axis.
			device.Transform.World = Matrix.Multiply(temp , Matrix.RotationAxis(new Vector3(0,1f,0) ,(float) (Math.PI / 4.0f))); 
			
			
			// reset y 
			temp = Matrix.Translation( 0 , saveY , 0 );
			device.Transform.World = Matrix.Multiply(temp , device.Transform.World); 
		} 

		/// <summary>
		/// There must be a cleaner way of doing this but my 3D trig are not up to it
		/// Limitation does not handle rotaions
		/// </summary>
		/// <param name="X"></param>
		/// <param name="Y"></param>
		
		private PointF Pick(int X , int Y)
		{

						
			//float yPlain = device.Transform.World.M42;  
			//Debug.WriteLine("Hexgrid: " + hexGrid.Width + " Y:" + hexGrid.Height); 
			Vector3 hexLoc = new Vector3( 0.0f, 0.0f , 0.0f); 
			hexLoc.Project(device.Viewport , device.Transform.Projection,
				device.Transform.View, device.Transform.World);
			//Debug.WriteLine(hexLoc);
			Vector3 hexLocEnd = new Vector3( hexGrid.Width, 0.0f , hexGrid.Height); 
			hexLocEnd.Project(device.Viewport , device.Transform.Projection,
				device.Transform.View, device.Transform.World);
			// Debug.WriteLine(hexLocEnd);

			float xratio =  hexGrid.Width / (hexLocEnd.X - hexLoc.X) ;
			float yratio = hexGrid.Height /  ( hexLocEnd.Y - hexLoc.Y)  ; 

			PointF result = new PointF(  (X - hexLoc.X)* xratio, (Y - hexLoc.Y) * yratio); 
			return result; 

		}


        
        
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        static void Main() 
        {
            using (HexEngine engine = new HexEngine())
            {                                 
                if (engine.CreateGraphicsSample())
                    engine.Run();
            }
        }
    }
}
