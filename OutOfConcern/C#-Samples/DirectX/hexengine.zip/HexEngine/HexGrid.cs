using System;
using System.Diagnostics;
using System.Drawing;
using Microsoft.DirectX;
using Microsoft.DirectX.Direct3D;

namespace HexEngine
{
	/// <summary>
	/// Summary description for HexGrid.
	/// </summary>
	public class HexGrid
	{
		Hexagon[,] hexagons; 

		float radius ;
		float width ;
		float height ;
		float side ;
		float H  ;
		float gradient ;

		int[] indexBufferLength;

		public const int NUMBER_OF_TEXTURES = 3; 
		int numberOfTextures = NUMBER_OF_TEXTURES; 


		private HexGrid( int x , int y , int size , Hexagon[] hexArray)
		{
			if (hexArray == null || x < 1 || y < 1 )
				throw new ArgumentException("Arguments incorrect");
			if (hexArray.Length > x * y  )
				throw new ArgumentException("Arguments incorrect - Array too big");

			hexagons = new Hexagon[x , y]; 


			for (int i = 0 ; i < x ; i++)
			{
				for (int j = 0 ; j < x ; j++)
				{
					hexagons[i,j] = hexArray[i + x * j]; 
				}
			}

			// pre set some values
			const float SIN30 = 0.5f;
			const float COS30 = 0.86602540378443864676372317075294f;
			this.side = size; 
			this.radius = this.side * COS30;
			this.width = this.Radius * 2 ;
			this.H  = this.side * SIN30;
			this.height = 2*H + side;
			this.gradient = H/Radius;
		}


		public static HexGrid Load (string fileName , Type hexagonType)
		{
			return null; 
			// TODO 
		}

		public static void Save (string fileName)
		{
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="X"> number of horizontal hexagons</param>
		/// <param name="Y"> number of vertical hexagons</param>
		/// <param name="size"> hex size</param>
		/// <returns></returns>
		public static HexGrid Generate(int X , int Y ,int size)
		{
			Hexagon[] hexes = new Hexagon[X * Y];
			for ( int i = 0 ; i < X* Y ; i ++)
			{
				hexes[i] = new Hexagon(i%Y , i / Y  );
			}
			return new HexGrid(X,Y ,size, hexes); 
		}

		public static HexGrid Generate(int X , int Y ,int size,  Hexagon[] hexes)
		{
			return new HexGrid(X,Y ,size, hexes); 
		}

		public Hexagon GetHexagonByPixel (int x , int y)
		{
			Point pnt = GetPointByPixel(x,y);
			Hexagon hex; 
			hex =  this.hexagons[pnt.X,pnt.Y]; 
			return hex; 
		}

		/// <summary>
		///  used for mouse etc and more efficient than mask . 
		/// </summary>
		/// <param name="x"></param>
		/// <param name="y"></param>
		/// <returns></returns>
		/// 
		// TODO add int version 
		public Point GetPointByPixel (float x , float y)
		{
			Debug.WriteLine( "X" + x + " Y: " + y ); 

//			int sectX = Convert.ToInt32(x)/ Convert.ToInt32(  (2 *  this.Radius)); 
			int sectX = Convert.ToInt32(x) / Convert.ToInt32((2 *  this.Radius)); 
			int sectY = Convert.ToInt32(y ) / Convert.ToInt32((this.H + this.side)); 	
			float sectPxlX = x % (2 * this.Radius);
			float sectPxlY = y  - ( sectY * (this.H + this.side));
			Debug.WriteLine("sectPxlY " +  sectPxlY );
	
				int arrayXIndex = sectX ; 
			int arrayYIndex = sectY;

			// A section 
			// sections correct
			if ( (sectY & 1) == 0) // 0 
			{
				Debug.WriteLine("A section"); 
				// A type section
				if ( sectPxlY  < ( this.H - sectPxlX * this.gradient ))
				{
					// left edge
					arrayXIndex--; 
					arrayYIndex--;
				}
					// right edge 
				if (( sectPxlY ) < ( -this.H + sectPxlX * this.gradient ))
				{
					// left edge
					//arrayXIndex--; 
					arrayYIndex--;
				}
			}
			else
			{
				// B type section 
			Debug.WriteLine("B section"); 

				if (sectPxlX >= this.radius)
				{
					// right side
					if (sectPxlY < (2*this.H - sectPxlX * this.gradient))
					{
						// left edge
						//arrayXIndex--; 
						arrayYIndex--;
					}
				}
				if (sectPxlX < this.radius)
				{
					// left side
					//arrayXIndex = sectX ; 
					//arrayYIndex = sectY ;
					if (sectPxlY < (sectPxlX * this.gradient ))
						arrayYIndex--;
					else 
						arrayXIndex--; 
				}

			}
			return new Point(arrayXIndex ,arrayYIndex); 
		}

		public PointF GetTopLeftPixelBoundingRectangle (int x , int y)
		{
			// tird int first but does not line up. 

			PointF point = new PointF(
				x * 2 * Radius + ( y & 1) * Radius ,
				y *  (this.H + this.side) ); 
			return point; 
		}


		//todo get subHexGrid

		
		public IndexBuffer[] CreateIndexBuffer(Device device)
		{
			// index by terrain .... using fans

			this.indexBufferLength = new int[numberOfTextures];
			Hexagon hex = null; 
			int index =0; 
			int maxIndex = 0; 

			// find how many hex's for each texture
			for (int x = 0 ; x < this.X; x++)
			{
				for (int y = 0 ;  y < this.Y; y++)
				{
					hex = this.hexagons[x,y];
					index = hex.TextureNumber;
					if (index > maxIndex)
						maxIndex = index; 
					indexBufferLength[index]++; 
				}
			}
			this.numberOfTextures = maxIndex;   // trim textures to actual amount found

			// create the buffers
			IndexBuffer[] newIndexBuffers = new IndexBuffer[numberOfTextures+1]; 
			for (int i = 0 ; i < maxIndex+1 ; i++)
			{
				if ( indexBufferLength[i] > 0) // cant create 0 length index buffer
					newIndexBuffers[i] = new IndexBuffer(typeof(short), 8 * indexBufferLength[i] , device, Usage.WriteOnly, Pool.Default);
			}
			return newIndexBuffers; 
		}

		// System.EventArgs e
		public void GenerateIndexBuffer(IndexBuffer[] source )
		{
			// index by terrain .... using fans
			// find how many hex's for each texture

			short[][] indexData = new short[source.Length][];
			for (int i =0 ; i < source.Length ;i++)
			{
				if ( source[i] == null)
				{
					// hextype / texture not present 
					indexData[i] = new short[0];
				}
				else
				{
					indexData[i] = new short[8 * this.indexBufferLength[i]];
				}
			}
			int[] count = new int[source.Length];
			for (int y = 0 ;  y < this.Y; y++)
			{
				for (int x = 0 ; x < this.X; x++)
				{
					short vertex = (short) (6*(x+ y*this.X));
					Hexagon hex = this.hexagons[x,y];
					
					int index = hex.TextureNumber;
					indexData[index][count[index]] = vertex; // 012
					count[index]++;
					indexData[index][count[index]] = vertex ;
					count[index]++;
					indexData[index][count[index]] = (short) (vertex + 5);
					count[index]++;
					indexData[index][count[index]] = (short) (vertex + 1) ; //025
					count[index]++;
					indexData[index][count[index]] = (short) (vertex + 4);
					count[index]++;
					indexData[index][count[index]] = (short) (vertex + 2);
					count[index]++;  
					indexData[index][count[index]] = (short) (vertex +  3); // 523
					count[index]++;
					indexData[index][count[index]] = (short) (vertex + 3);
					count[index]++;

				}
			}

			// set the data
			for ( int j =0 ; j < source.Length ; j++)
			{
				if (source[j] != null)
				{
					IndexBuffer buffer = source[j]; 
					buffer.SetData(indexData[j], 0, 0);
				}
			}

		}

		public VertexBuffer CreateVertexBuffer(Device device)
		{
			return new VertexBuffer(typeof(CustomVertex.PositionNormalTextured), 6 * this.X * this.Y , device, Usage.WriteOnly, CustomVertex.PositionNormalTextured.Format, Pool.Default);
		}

		public void GenerateVertexBufferData(VertexBuffer source )
		{
			const float yValue = 0f;
			VertexBuffer vb = source;
			// Create a vertex buffer (100 customervertex)
			CustomVertex.PositionNormalTextured[] verts = (CustomVertex.PositionNormalTextured[])vb.Lock(0,0); // Lock the buffer (which will return our structs)
	
			for (int y = 0 ; y < this.Y ; y++)
				for (int x = 0 ;  x < this.X; x++)
				{
					//Hexagon hex = this.hexagons[x,y];
					PointF topLeft= this.GetTopLeftPixelBoundingRectangle(x , y ); 
					// vertex 0
					verts[6*(x+ y*this.X)].SetPosition(new Vector3( topLeft.X , yValue, topLeft.Y + this.H ));
					verts[6*(x+ y*this.X)].Tu = 0.0f;
					verts[6*(x+ y*this.X)].Tv = (float) this.H/ this.height; 
					// vertex 1 top 
					verts[6*(x+ y*this.X)+1].SetPosition(new Vector3( topLeft.X + this.Radius, yValue, topLeft.Y  ));
					verts[6*(x+ y*this.X)+1].Tu = 0.5f;
					verts[6*(x+ y*this.X)+1].Tv = 0.0f; 
					// vertex 2
					verts[6*(x+ y*this.X)+2].SetPosition(new Vector3( topLeft.X + this.width, yValue, topLeft.Y + this.H ));
					verts[6*(x+ y*this.X)+2].Tu = 1.0f;
					verts[6*(x+ y*this.X)+2].Tv = (float) this.H/ this.height; 
					// vertex 3
					verts[6*(x+ y*this.X)+3].SetPosition(new Vector3( topLeft.X + this.width , yValue, topLeft.Y + this.H + this.side ));
					verts[6*(x+ y*this.X)+3].Tu = 1.0f;
					verts[6*(x+ y*this.X)+3].Tv = (float) (this.H + this.side) / this.height; 
					// vertex 4 bottom 
					verts[6*(x+ y*this.X)+4].SetPosition(new Vector3( topLeft.X + this.Radius ,yValue, topLeft.Y + this.height ));
					verts[6*(x+ y*this.X)+4].Tu = 0.5f;
					verts[6*(x+ y*this.X)+4].Tv = 1.0f ; 
					// vertex 5
					verts[6*(x+ y*this.X)+5].SetPosition(new Vector3( topLeft.X, yValue, topLeft.Y + this.H + this.side ));
					verts[6*(x+ y*this.X)+5].Tu = 0.0f;
					verts[6*(x+ y*this.X)+5].Tv = (float) (this.H + this.side)/ this.height; 
	
					/*for ( int i = 0; i < 6; i++)
					{
						Point topLeft= this.GetTopLeftPixelBoundingRectangle(x , y ); 
						verts[6*(x+ y*this.X)+i].SetPosition(new Vector3( x , 0, y ));
						verts[6*(x+ y*this.X)+i].Tu =  ;
						verts[6*(x+ y*this.X)+i].Tv = ; 
						// TODO verts[indexY+(indexX*bufferSize)].SetNormal = (new Vector3(indexX, -(float)points[indexX,indexY], indexY));
					}*/ 
				}

			int countA = 0; 
	//		foreach (CustomVertex.PositionNormalTextured verto in verts)
	//		{
	//			Debug.WriteLine("vertext "+ countA++ + " : " + verto.X + "/" + verto.Z + "/"  + verto.Y);
	//		}

			// Unlock (and copy) the data
			vb.Unlock();
		}

		// public int NumVertices

		public float Radius { get { return this.radius;}}
		public float Side { get { return this.side;}}
		public int X { get { return hexagons.GetLength(0);}}
		public int Y { get { return hexagons.GetLength(1);}}
		public int Width { get { return Convert.ToInt32(this.X * this.width);}}
		public int Height { get { return Convert.ToInt32(this.Y * (this.H + this.side));}}
		public int[] IndexBufferLength { get { return this.indexBufferLength;}}
		public int NumberOfTextures { get { return this.numberOfTextures ;}  set { this.numberOfTextures = value;}}



	}
}
