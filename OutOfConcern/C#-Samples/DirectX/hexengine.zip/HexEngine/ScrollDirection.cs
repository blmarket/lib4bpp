using System;

namespace HexEngine
{
	/// <summary>
	/// Summary description for ScrollDirection.
	/// </summary>
	public enum ScrollDirection
	{
		UP,
		DOWN,
		LEFT,
		RIGHT,
		NE, 
		SE,
		SW,
		NW,
		ZOOM_IN,
		ZOOM_OUT
	}
}
