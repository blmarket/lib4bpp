﻿#region File Description
//-----------------------------------------------------------------------------
// Game1.cs
//
// Microsoft XNA Community Game Platform
// Copyright (C) Microsoft Corporation. All rights reserved.
//-----------------------------------------------------------------------------
#endregion

using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Net;
using Microsoft.Xna.Framework.Storage;

namespace StencilShadow
{
    
    /// <summary>
    /// This is the main type for your game
    /// </summary>
    public class Game1 : Microsoft.Xna.Framework.Game
    {
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;

        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
            graphics.PreferredDepthStencilFormat = SelectStencilMode();
        }
        private static DepthFormat SelectStencilMode()
        {
            // Check stencil formats
            GraphicsAdapter adapter = GraphicsAdapter.DefaultAdapter;
            SurfaceFormat format = adapter.CurrentDisplayMode.Format;
            if (adapter.CheckDepthStencilMatch(DeviceType.Hardware, format, format, DepthFormat.Depth24Stencil8))
                return DepthFormat.Depth24Stencil8;
            else if (adapter.CheckDepthStencilMatch(DeviceType.Hardware, format, format, DepthFormat.Depth24Stencil8Single))
                return DepthFormat.Depth24Stencil8Single;
            else if (adapter.CheckDepthStencilMatch(DeviceType.Hardware, format, format, DepthFormat.Depth24Stencil4))
                return DepthFormat.Depth24Stencil4;
            else if (adapter.CheckDepthStencilMatch(DeviceType.Hardware, format, format, DepthFormat.Depth15Stencil1))
                return DepthFormat.Depth15Stencil1;
            else
                throw new InvalidOperationException("Could Not Find Stencil Buffer for Default Adapter");
        }

        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        Matrix View;
        Matrix Projection;
        Quad wall;
        Plane wallPlane;
        protected override void Initialize()
        {
            // Create the View and Projection matrices
            View = Matrix.CreateLookAt(new Vector3(1, -2, 10), Vector3.Zero, Vector3.Up);
            Projection = Matrix.CreatePerspectiveFieldOfView(MathHelper.PiOver4, 4.0f / 3.0f, 1, 500);
            // Create a new Textured Quad to represent a wall
            wall = new Quad(Vector3.Zero, Vector3.Backward, Vector3.Up, 7, 7);
            // Create a Plane using three points on the Quad
            wallPlane = new Plane(wall.UpperLeft, wall.UpperRight, wall.LowerLeft);

            base.Initialize();
        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        Model model;
        Matrix modelWorld;
        Texture2D texture;

        VertexDeclaration wallVertexDecl;
        BasicEffect quadEffect;
        Vector3 shadowLightDir;
        Matrix shadow;
        protected override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch(GraphicsDevice);
            model = Content.Load<Model>("axes");
            // Create the world Matrix for the model, placed to be near the wall:
            modelWorld = Matrix.CreateTranslation(new Vector3(0, 0, 15));
            modelWorld *= Matrix.CreateScale(.1f);
            texture = Content.Load<Texture2D>("wallpaper");

            quadEffect = new BasicEffect(graphics.GraphicsDevice, null);
            quadEffect.EnableDefaultLighting();
            quadEffect.View = View;
            quadEffect.Projection = Projection;
            quadEffect.TextureEnabled = true;
            quadEffect.Texture = texture;
            shadowLightDir = quadEffect.DirectionalLight0.Direction;
            // Use the wall plane to create a shadow matrix, and make the shadow slightly
            // higher than the wall.  The shadow is based on the strongest light
            shadow = Matrix.CreateShadow(shadowLightDir, wallPlane) *
                Matrix.CreateTranslation(wall.Normal / 100);
            wallVertexDecl = new VertexDeclaration(graphics.GraphicsDevice,
                        VertexPositionNormalTexture.VertexElements);
        }
            
        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// all content.
        /// </summary>
        protected override void UnloadContent()
        {
            // TODO: Unload any non ContentManager content here
        }

        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {
            // Allows the game to exit
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed)
                this.Exit();

            // TODO: Add your update logic here

            base.Update(gameTime);
        }

        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.CornflowerBlue);

            // Draw floor, and draw model
            DrawQuad();

            foreach (ModelMesh mesh in model.Meshes)
            {
                foreach (BasicEffect effect in mesh.Effects)
                {
                    effect.EnableDefaultLighting();

                    effect.View = View;
                    effect.Projection = Projection;
                    effect.World = modelWorld;
                }
                mesh.Draw();
            }
            // Draw shadow, using the stencil buffer to prevent drawing overlapping
            // polygons

            // Clear stencil buffer to zero.
            GraphicsDevice.Clear(ClearOptions.Stencil, Color.Black, 0, 0);
            GraphicsDevice.RenderState.StencilEnable = true;
            // Draw on screen if 0 is the stencil buffer value           
            GraphicsDevice.RenderState.ReferenceStencil = 0;
            GraphicsDevice.RenderState.StencilFunction = CompareFunction.Equal;
            // Increment the stencil buffer if we draw
            GraphicsDevice.RenderState.StencilPass = StencilOperation.Increment;
            // Setup alpha blending to make the shadow semi-transparent
            GraphicsDevice.RenderState.AlphaBlendEnable = true;
            GraphicsDevice.RenderState.SourceBlend = Blend.SourceAlpha;
            GraphicsDevice.RenderState.DestinationBlend = Blend.InverseSourceAlpha;
            // Draw the shadow without lighting
            foreach (ModelMesh mesh in model.Meshes)
            {
                foreach (BasicEffect effect in mesh.Effects)
                {
                    effect.AmbientLightColor = Vector3.Zero;
                    effect.Alpha = 0.5f;
                    effect.DirectionalLight0.Enabled = false;
                    effect.DirectionalLight1.Enabled = false;
                    effect.DirectionalLight2.Enabled = false;
                    effect.View = View;
                    effect.Projection = Projection;
                    effect.World = modelWorld * shadow;
                }
                mesh.Draw();
            }
            // Return render states to normal            

            // turn stencilling off
            GraphicsDevice.RenderState.StencilEnable = false;
            // turn alpha blending off
            GraphicsDevice.RenderState.AlphaBlendEnable = false;

            base.Draw(gameTime);
        }
        private void DrawQuad()
        {
            graphics.GraphicsDevice.VertexDeclaration = wallVertexDecl;

            quadEffect.Begin();
            foreach (EffectPass pass in quadEffect.CurrentTechnique.Passes)
            {
                pass.Begin();

                graphics.GraphicsDevice.DrawUserIndexedPrimitives<VertexPositionNormalTexture>(
                    PrimitiveType.TriangleList, wall.Vertices, 0, 4, wall.Indexes, 0, 2);

                pass.End();
            }
            quadEffect.End();
        }
    }
}
