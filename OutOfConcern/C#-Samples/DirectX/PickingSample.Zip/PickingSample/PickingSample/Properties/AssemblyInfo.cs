﻿#region File Description
//-----------------------------------------------------------------------------
// AssemblyInfo.cs
//
// Microsoft Game Technology Group
// Copyright (C) Microsoft Corporation. All rights reserved.
//-----------------------------------------------------------------------------
#endregion

#region Using Statements
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
#endregion

//Descriptive Assembly attributes
[assembly: AssemblyTitle("Picking Sample")]
[assembly: AssemblyProduct("Picking Sample")]
[assembly: AssemblyDescription("This sample demonstrates how to translate between 3D world coordinates and 2D screen coordinates, allowing the user to hover over a 3D object with a mouse cursor and displaying text above the chosen object.")]
[assembly: AssemblyCompany("Microsoft Corporation")]
[assembly: AssemblyCopyright("Copyright © Microsoft 2008")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: AssemblyVersion("1.0.0.0")]

//ComVisible is false for this component.
[assembly: ComVisible(false)]
[assembly: Guid("12751409-303b-4184-b24a-fc80ab4b3964")]

