using System;
using System.ComponentModel;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;
using System.Windows.Forms.Design;
using System.Windows.Forms;
using System.Drawing;
using System.Drawing.Design;

namespace Microsoft.Samples {

    /// <summary>
    /// Tab is a specialized ToolStripButton with extra padding
    /// </summary>
    [System.ComponentModel.DesignerCategory("code")]
    [ToolStripItemDesignerAvailability(ToolStripItemDesignerAvailability.None)] // turn off the ability to add this in the DT, the TabPageSwitcher designer will provide this.
    public class Tab : ToolStripButton {
        
        private TabStripPage tabStripPage;
        
        /// <summary>
        /// Constructor for tab - support all overloads.
        /// </summary>
        public Tab() {
            Initialize();
        }
        public Tab(string text):base(text,null,null) {
            Initialize();
        }
        public Tab(Image image):base(null,image,null) {
            Initialize();
        }
        public Tab(string text, Image image):base(text,image,null) {
            Initialize();
        }
        public Tab(string text, Image image, EventHandler onClick):base(text,image,onClick) {
            Initialize();            
        }
        public Tab(string text, Image image, EventHandler onClick, string name):base(text,image,onClick,name) {
            Initialize();
        }

        /// <summary>
        /// Common initialization code between all CTORs.
        /// </summary>
        private void Initialize() {
            CheckOnClick = true;  // Tab will use the "checked" property in order to represent the "selected tab".
        }

        /// <summary>
        /// Hide the CheckOnClick from the Property Grid so that we can use it for our own purposes. 
        /// </summary>
        [DefaultValue(true)]
        public new bool CheckOnClick {
            get { return base.CheckOnClick; }
            set { base.CheckOnClick = value; }
        }

        /// <summary>
        /// Specify the default display style to be ImageAndText
        /// </summary>
        protected override ToolStripItemDisplayStyle DefaultDisplayStyle {
            get {
                return ToolStripItemDisplayStyle.ImageAndText;
            }
        }
     
        /// <summary>
        /// Add extra internal spacing so we have enough room for our curve.
        /// </summary>
        protected override Padding DefaultPadding {
            get {
                return new Padding(35, 0, 6, 0);
            }
        }

        /// <summary>
        /// The associated TabStripPage - when Tab is clicked, this TabPage will be selected.
        /// </summary>
        [DefaultValue("null")]
        public TabStripPage TabStripPage {
            get {
                return tabStripPage;
            }
            set {
                tabStripPage = value;
            }
        }

    
      
    }
}
