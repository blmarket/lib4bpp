#if !defined(__TEST_DELEGATE2_H__INCLUDED__)
#define __TEST_DELEGATE2_H__INCLUDED__

// ===========================================================================

void test_delegate2();

#endif  // #if !defined(__TEST_DELEGATE2_H__INCLUDED__)
