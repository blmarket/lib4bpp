#include <cstdlib>
#include <iostream>
#include "../../common/test_delegate.h"
#include "../../common/test_delegate2.h"

int main(int argc, char *argv[])
{
  test_delegate();
  test_delegate2();    
  
  system("PAUSE");
  return EXIT_SUCCESS;
}
